public class Minimax {
//  public static int minimax(State estado, int profundidade, boolean maximizandoJogador) {
  
}